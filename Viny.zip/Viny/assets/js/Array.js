const word = document.querySelector(`#txtInput`);
const res = document.querySelector(`#txtInfo`);
let array = [];

function push() { //adicona no final
    array.push(word.value);
    console.log("adicionado : ", word.value);
    info();
}

function unshift() { //adiciona no inicio
    array.unshift(word.value);
    console.log("adicionado : ", word.value);
    info();
}

function pop() { // remove do final
    array.pop();
    info();
}

function shift() { // remove do inicio
    array.shift();
    info();
}

function position() {
    let position = prompt(`Choose a element in the array: `);
    alert(`${array[position]}`)
}

function info() {
    res.innerHTML = `${array}`;
}